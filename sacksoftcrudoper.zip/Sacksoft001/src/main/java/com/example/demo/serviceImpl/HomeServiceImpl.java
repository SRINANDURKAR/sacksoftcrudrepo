package com.example.demo.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.User;
import com.example.demo.repository.HomeRepository;
import com.example.demo.service.HomeService;
@Service
public class HomeServiceImpl implements HomeService{
	@Autowired
	HomeRepository hr;

	@Override
	public void saveDetails(User u) {
			hr.save(u);
		
	}

	@Override
	public Iterable<User> getUsers() {
		// TODO Auto-generated method stub
		return hr.findAll();
	}

	@Override
	public Iterable<User> displayAll() {
		// TODO Auto-generated method stub
		return hr.findAll();
	}

	@Override
	public void deleteData(int id) {
		// TODO Auto-generated method stub
		hr.deleteById(id);
	}

	@Override
	public User updateuser(User u) {
		// TODO Auto-generated method stub
		return null;
	}

	
	

}
