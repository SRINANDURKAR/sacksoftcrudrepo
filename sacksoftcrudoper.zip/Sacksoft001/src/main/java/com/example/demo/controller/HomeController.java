package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.User;
import com.example.demo.service.HomeService;

@RestController								
public class HomeController {

	@Autowired
	HomeService hs;

	@PostMapping("/adduser")
	public String savedetails(@RequestBody User u)
	{	hs.saveDetails(u);
		return "details saved";
	}
	
	
	@GetMapping("/getuser")
	public Iterable<User> getUser()
	{Iterable<User>user=hs.getUsers();
	return user;}
	
	@PutMapping("/update/{id}")	
	public String updateData(@RequestBody User u) {
	hs.saveDetails(u);
	return "details updated successfully";
	}


	@DeleteMapping("/delete/{id}")
	public String DeleteData(@PathVariable int id)
	{
		hs.deleteData(id);
		return "Data deleted";
	}
}
