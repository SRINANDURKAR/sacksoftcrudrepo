package com.example.demo.service;

import com.example.demo.model.User;



public interface HomeService {

public	void saveDetails(User u);

public Iterable<User> getUsers();

public Iterable<User> displayAll();

public void deleteData(int id);

public User updateuser(User u);



}
